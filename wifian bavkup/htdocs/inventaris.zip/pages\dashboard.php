<?php
// pages/dashboard.php
$pageTitle = 'Dashboard Inventory';
require_once __DIR__ . '/../includes/header.php';
$pdo = getDBConnection();

// Fetch Stat Cards Data
$totalProduk = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn() ?: 0;
$totalStok = $pdo->query("SELECT SUM(stok) FROM products")->fetchColumn() ?: 0;
$totalMasuk = $pdo->query("SELECT SUM(jumlah) FROM stock_in")->fetchColumn() ?: 0;
$totalKeluar = $pdo->query("SELECT SUM(jumlah) FROM stock_out")->fetchColumn() ?: 0;
$totalKategori = $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn() ?: 0;
$stokMenipis = $pdo->query("SELECT COUNT(*) FROM products WHERE stok <= stok_minimum AND stok > 0")->fetchColumn() ?: 0;
$stokHabis = $pdo->query("SELECT COUNT(*) FROM products WHERE stok = 0")->fetchColumn() ?: 0;

// Fetch Monthly Bar Chart Data (Last 6 Months)
$months = [];
$dataMasuk = [];
$dataKeluar = [];

for ($i = 5; $i >= 0; $i--) {
    $monthKey = date('Y-m', strtotime("-$i months"));
    $monthLabel = date('M Y', strtotime("-$i months"));
    $months[] = $monthLabel;

    $stmtM = $pdo->prepare("SELECT SUM(jumlah) FROM stock_in WHERE DATE_FORMAT(tanggal, '%Y-%m') = :m");
    $stmtM->execute([':m' => $monthKey]);
    $dataMasuk[] = (int)($stmtM->fetchColumn() ?: 0);

    $stmtK = $pdo->prepare("SELECT SUM(jumlah) FROM stock_out WHERE DATE_FORMAT(tanggal, '%Y-%m') = :m");
    $stmtK->execute([':m' => $monthKey]);
    $dataKeluar[] = (int)($stmtK->fetchColumn() ?: 0);
}

// Fetch Category Pie Chart Data
$catQuery = $pdo->query("
    SELECT c.nama_kategori, COALESCE(SUM(p.stok), 0) as total_stok
    FROM categories c
    LEFT JOIN products p ON c.id = p.kategori_id
    GROUP BY c.id, c.nama_kategori
    ORDER BY total_stok DESC
");
$catLabels = [];
$catData = [];
while ($row = $catQuery->fetch()) {
    $catLabels[] = $row['nama_kategori'];
    $catData[] = (int)$row['total_stok'];
}

// Fetch 10 Latest Transactions (Union Stock In and Stock Out)
$recentTransactionsQuery = $pdo->query("
    (SELECT 
        id, 
        nomor_transaksi, 
        tanggal, 
        'Masuk' AS jenis, 
        product_id, 
        jumlah, 
        created_by, 
        created_at 
    FROM stock_in)
    UNION ALL
    (SELECT 
        id, 
        nomor_transaksi, 
        tanggal, 
        'Keluar' AS jenis, 
        product_id, 
        jumlah, 
        created_by, 
        created_at 
    FROM stock_out)
    ORDER BY created_at DESC, id DESC
    LIMIT 10
");

$recentTransactions = [];
while ($t = $recentTransactionsQuery->fetch()) {
    // Get product name
    $stmtP = $pdo->prepare("SELECT nama_barang FROM products WHERE id = :id");
    $stmtP->execute([':id' => $t['product_id']]);
    $t['nama_barang'] = $stmtP->fetchColumn() ?: 'Barang Dihapus';

    // Get user name
    $stmtU = $pdo->prepare("SELECT nama FROM users WHERE id = :id");
    $stmtU->execute([':id' => $t['created_by']]);
    $t['nama_user'] = $stmtU->fetchColumn() ?: 'System';

    $recentTransactions[] = $t;
}
?>

<!-- STAT CARDS GRID -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
    
    <!-- Total Produk -->
    <div class="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-subtle flex items-center justify-between group hover:border-sky-300 transition-all">
        <div>
            <div class="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Produk</div>
            <div class="text-2xl font-extrabold text-slate-800 mt-1"><?= number_format($totalProduk) ?></div>
            <div class="text-xs text-slate-500 mt-1">Item terdaftar</div>
        </div>
        <div class="w-12 h-12 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center text-xl font-bold group-hover:scale-110 transition-transform">
            <i class="fa-solid fa-boxes-stacked"></i>
        </div>
    </div>

    <!-- Total Stok Barang -->
    <div class="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-subtle flex items-center justify-between group hover:border-emerald-300 transition-all">
        <div>
            <div class="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Stok Barang</div>
            <div class="text-2xl font-extrabold text-slate-800 mt-1"><?= number_format($totalStok) ?></div>
            <div class="text-xs text-slate-500 mt-1">Total seluruh unit</div>
        </div>
        <div class="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-xl font-bold group-hover:scale-110 transition-transform">
            <i class="fa-solid fa-cubes"></i>
        </div>
    </div>

    <!-- Total Barang Masuk -->
    <div class="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-subtle flex items-center justify-between group hover:border-blue-300 transition-all">
        <div>
            <div class="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Barang Masuk</div>
            <div class="text-2xl font-extrabold text-slate-800 mt-1"><?= number_format($totalMasuk) ?></div>
            <div class="text-xs text-slate-500 mt-1">Unit diterima</div>
        </div>
        <div class="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-xl font-bold group-hover:scale-110 transition-transform">
            <i class="fa-solid fa-arrow-down-to-bracket"></i>
        </div>
    </div>

    <!-- Total Barang Keluar -->
    <div class="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-subtle flex items-center justify-between group hover:border-indigo-300 transition-all">
        <div>
            <div class="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Barang Keluar</div>
            <div class="text-2xl font-extrabold text-slate-800 mt-1"><?= number_format($totalKeluar) ?></div>
            <div class="text-xs text-slate-500 mt-1">Unit terdistribusi</div>
        </div>
        <div class="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-xl font-bold group-hover:scale-110 transition-transform">
            <i class="fa-solid fa-arrow-up-from-bracket"></i>
        </div>
    </div>

    <!-- Total Kategori -->
    <div class="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-subtle flex items-center justify-between group hover:border-purple-300 transition-all">
        <div>
            <div class="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Kategori</div>
            <div class="text-2xl font-extrabold text-slate-800 mt-1"><?= number_format($totalKategori) ?></div>
            <div class="text-xs text-slate-500 mt-1">Kelompok produk</div>
        </div>
        <div class="w-12 h-12 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center text-xl font-bold group-hover:scale-110 transition-transform">
            <i class="fa-solid fa-tags"></i>
        </div>
    </div>

    <!-- Stok Menipis -->
    <div class="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-subtle flex items-center justify-between group hover:border-amber-300 transition-all">
        <div>
            <div class="text-xs font-bold text-amber-600 uppercase tracking-wider">Stok Menipis</div>
            <div class="text-2xl font-extrabold text-amber-700 mt-1"><?= number_format($stokMenipis) ?></div>
            <div class="text-xs text-amber-600 mt-1">Perlu reorder</div>
        </div>
        <div class="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center text-xl font-bold group-hover:scale-110 transition-transform">
            <i class="fa-solid fa-triangle-exclamation"></i>
        </div>
    </div>

    <!-- Stok Habis -->
    <div class="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-subtle flex items-center justify-between group hover:border-rose-300 transition-all">
        <div>
            <div class="text-xs font-bold text-rose-600 uppercase tracking-wider">Stok Habis</div>
            <div class="text-2xl font-extrabold text-rose-700 mt-1"><?= number_format($stokHabis) ?></div>
            <div class="text-xs text-rose-600 mt-1">Kosong total</div>
        </div>
        <div class="w-12 h-12 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center text-xl font-bold group-hover:scale-110 transition-transform">
            <i class="fa-solid fa-ban"></i>
        </div>
    </div>

</div>

<!-- CHARTS SECTION -->
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
    
    <!-- Bar Chart (2 columns) -->
    <div class="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-subtle">
        <div class="flex items-center justify-between mb-4">
            <div>
                <h3 class="text-base font-bold text-slate-800">Grafik Barang Masuk & Keluar</h3>
                <p class="text-xs text-slate-500">Perbandingan per bulan (6 bulan terakhir)</p>
            </div>
            <span class="p-2 bg-slate-100 text-slate-600 rounded-lg text-xs font-medium">Realtime</span>
        </div>
        <div class="h-72">
            <canvas id="barChart"></canvas>
        </div>
    </div>

    <!-- Pie Chart (1 column) -->
    <div class="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-subtle flex flex-col justify-between">
        <div>
            <h3 class="text-base font-bold text-slate-800 mb-1">Distribusi Stok Kategori</h3>
            <p class="text-xs text-slate-500 mb-4">Proporsi stok berdasarkan kategori</p>
            <div class="h-60 relative flex items-center justify-center">
                <canvas id="pieChart"></canvas>
            </div>
        </div>
    </div>

</div>

<!-- 10 RECENT TRANSACTIONS TABLE -->
<div class="bg-white rounded-2xl border border-slate-200/80 shadow-subtle overflow-hidden">
    <div class="p-5 border-b border-slate-100 flex items-center justify-between">
        <div>
            <h3 class="text-base font-bold text-slate-800">10 Transaksi Terakhir</h3>
            <p class="text-xs text-slate-500">Aktivitas barang masuk dan keluar terbaru</p>
        </div>
        <i class="fa-solid fa-clock-rotate-left text-slate-400 text-lg"></i>
    </div>

    <div class="overflow-x-auto">
        <table class="w-full text-left text-sm text-slate-600">
            <thead class="bg-slate-50 text-xs uppercase tracking-wider text-slate-500 font-semibold border-b border-slate-200/80">
                <tr>
                    <th class="px-5 py-3.5">Tanggal</th>
                    <th class="px-5 py-3.5">No. Transaksi</th>
                    <th class="px-5 py-3.5">Jenis</th>
                    <th class="px-5 py-3.5">Nama Barang</th>
                    <th class="px-5 py-3.5 text-right">Jumlah</th>
                    <th class="px-5 py-3.5">User</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
                <?php if (empty($recentTransactions)): ?>
                    <tr>
                        <td colspan="6" class="px-5 py-8 text-center text-slate-400 text-sm">
                            Belum ada transaksi recorded.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($recentTransactions as $tx): ?>
                        <tr class="hover:bg-slate-50/80 transition-colors">
                            <td class="px-5 py-3.5 whitespace-nowrap text-xs font-medium text-slate-700">
                                <?= date('d/m/Y', strtotime($tx['tanggal'])) ?>
                            </td>
                            <td class="px-5 py-3.5 font-mono text-xs text-slate-800 font-semibold">
                                <?= e($tx['nomor_transaksi']) ?>
                            </td>
                            <td class="px-5 py-3.5 whitespace-nowrap">
                                <?php if ($tx['jenis'] === 'Masuk'): ?>
                                    <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                                        <i class="fa-solid fa-arrow-down text-[10px]"></i> Barang Masuk
                                    </span>
                                <?php else: ?>
                                    <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
                                        <i class="fa-solid fa-arrow-up text-[10px]"></i> Barang Keluar
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="px-5 py-3.5 font-medium text-slate-800">
                                <?= e($tx['nama_barang']) ?>
                            </td>
                            <td class="px-5 py-3.5 text-right font-bold font-mono text-slate-800">
                                <?= number_format($tx['jumlah']) ?>
                            </td>
                            <td class="px-5 py-3.5 text-xs text-slate-500">
                                <i class="fa-regular fa-user text-slate-400 mr-1"></i><?= e($tx['nama_user']) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Chart.js Setup Scripts -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Bar Chart
    const ctxBar = document.getElementById('barChart').getContext('2d');
    new Chart(ctxBar, {
        type: 'bar',
        data: {
            labels: <?= json_encode($months) ?>,
            datasets: [
                {
                    label: 'Barang Masuk',
                    data: <?= json_encode($dataMasuk) ?>,
                    backgroundColor: '#0284c7',
                    borderRadius: 6,
                },
                {
                    label: 'Barang Keluar',
                    data: <?= json_encode($dataKeluar) ?>,
                    backgroundColor: '#f59e0b',
                    borderRadius: 6,
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'top' }
            },
            scales: {
                y: { beginAtZero: true, grid: { color: '#f1f5f9' } },
                x: { grid: { display: false } }
            }
        }
    });

    // Pie Chart
    const ctxPie = document.getElementById('pieChart').getContext('2d');
    new Chart(ctxPie, {
        type: 'doughnut',
        data: {
            labels: <?= json_encode($catLabels) ?>,
            datasets: [{
                data: <?= json_encode($catData) ?>,
                backgroundColor: [
                    '#0284c7', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#64748b'
                ],
                borderWidth: 2,
                borderColor: '#ffffff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom', labels: { boxWidth: 12 } }
            }
        }
    });
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
