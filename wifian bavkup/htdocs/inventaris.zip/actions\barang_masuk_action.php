<?php
// actions/barang_masuk_action.php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../pages/barang_masuk.php");
    exit();
}

$csrf_token = $_POST['csrf_token'] ?? '';
if (!verifyCSRFToken($csrf_token)) {
    setFlash('danger', 'Sesi invalid (CSRF Token error).');
    header("Location: ../pages/barang_masuk.php");
    exit();
}

$nomor_transaksi = trim($_POST['nomor_transaksi'] ?? '');
$tanggal = trim($_POST['tanggal'] ?? date('Y-m-d'));
$product_id = (int)($_POST['product_id'] ?? 0);
$jumlah = (int)($_POST['jumlah'] ?? 0);
$harga_beli = (float)($_POST['harga_beli'] ?? 0);
$keterangan = trim($_POST['keterangan'] ?? '');
$user_id = $_SESSION['user_id'] ?? null;

if ($product_id <= 0 || $jumlah <= 0) {
    setFlash('danger', 'Pilih barang dan jumlah masuk wajib lebih dari 0.');
    header("Location: ../pages/barang_masuk.php");
    exit();
}

$pdo = getDBConnection();

try {
    $pdo->beginTransaction();

    // 1. Insert transaction into stock_in
    $stmtIn = $pdo->prepare("
        INSERT INTO stock_in (nomor_transaksi, tanggal, product_id, jumlah, harga_beli, keterangan, created_by)
        VALUES (:no_tx, :tgl, :pid, :jml, :harga, :ket, :uid)
    ");
    $stmtIn->execute([
        ':no_tx' => $nomor_transaksi,
        ':tgl' => $tanggal,
        ':pid' => $product_id,
        ':jml' => $jumlah,
        ':harga' => $harga_beli,
        ':ket' => $keterangan,
        ':uid' => $user_id
    ]);

    // 2. Update product stock: Stok Baru = Stok Lama + Jumlah Masuk
    $stmtUp = $pdo->prepare("
        UPDATE products 
        SET stok = stok + :jml,
            harga_beli = CASE WHEN :harga > 0 THEN :harga ELSE harga_beli END
        WHERE id = :pid
    ");
    $stmtUp->execute([
        ':jml' => $jumlah,
        ':harga' => $harga_beli,
        ':pid' => $product_id
    ]);

    $pdo->commit();
    setFlash('success', "Transaksi Barang Masuk [$nomor_transaksi] berhasil disimpan dan stok telah bertambah $jumlah unit.");
} catch (PDOException $e) {
    $pdo->rollBack();
    if ($e->getCode() == 23000) {
        setFlash('danger', "Nomor transaksi '$nomor_transaksi' sudah digunakan.");
    } else {
        setFlash('danger', 'Gagal memproses barang masuk: ' . $e->getMessage());
    }
}

header("Location: ../pages/barang_masuk.php");
exit();
