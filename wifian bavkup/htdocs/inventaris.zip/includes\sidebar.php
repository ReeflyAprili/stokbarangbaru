<?php
// includes/sidebar.php
$currentPage = basename($_SERVER['PHP_SELF']);
$userRole = $_SESSION['role'] ?? 'Staff Gudang';
$settings = getStoreSettings();

$menuItems = [
    ['key' => 'dashboard.php', 'label' => 'Dashboard', 'icon' => 'fa-gauge-high', 'roles' => ['Admin', 'Staff Gudang']],
    ['key' => 'produk.php', 'label' => 'Produk', 'icon' => 'fa-boxes-stacked', 'roles' => ['Admin', 'Staff Gudang']],
    ['key' => 'barang_masuk.php', 'label' => 'Barang Masuk', 'icon' => 'fa-arrow-down-to-bracket', 'roles' => ['Admin', 'Staff Gudang']],
    ['key' => 'barang_keluar.php', 'label' => 'Barang Keluar', 'icon' => 'fa-arrow-up-from-bracket', 'roles' => ['Admin', 'Staff Gudang']],
    ['key' => 'stok_opname.php', 'label' => 'Stok Opname', 'icon' => 'fa-clipboard-check', 'roles' => ['Admin', 'Staff Gudang']],
    ['key' => 'laporan.php', 'label' => 'Laporan', 'icon' => 'fa-file-invoice-dollar', 'roles' => ['Admin', 'Staff Gudang']],
    ['key' => 'kategori.php', 'label' => 'Kategori Barang', 'icon' => 'fa-tags', 'roles' => ['Admin', 'Staff Gudang']],
    ['key' => 'pengguna.php', 'label' => 'Pengguna', 'icon' => 'fa-users-gear', 'roles' => ['Admin']],
    ['key' => 'pengaturan.php', 'label' => 'Pengaturan', 'icon' => 'fa-sliders', 'roles' => ['Admin']],
];
?>

<aside id="sidebar" class="w-64 bg-slate-900 text-slate-300 flex flex-col fixed lg:static inset-y-0 left-0 z-50 transform -translate-x-full lg:translate-x-0 transition-transform duration-300 ease-in-out shadow-2xl lg:shadow-none border-r border-slate-800">
    
    <!-- Sidebar Header / Branding -->
    <div class="p-5 border-b border-slate-800 flex items-center gap-3 bg-slate-950/40">
        <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center text-white font-black text-xl shadow-lg shadow-sky-500/20">
            <i class="fa-solid fa-wifi"></i>
        </div>
        <div class="overflow-hidden">
            <div class="text-xs font-bold uppercase tracking-wider text-sky-400">INVENTORY</div>
            <div class="text-sm font-extrabold text-white truncate"><?= e($settings['nama_toko']) ?></div>
        </div>
    </div>

    <!-- Navigation List -->
    <nav class="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        <div class="px-3 pb-2 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Menu Utama</div>
        
        <?php foreach ($menuItems as $item): ?>
            <?php if (in_array($userRole, $item['roles'])): ?>
                <?php $isActive = ($currentPage === $item['key']); ?>
                <a href="<?= $item['key'] ?>" class="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 <?= $isActive ? 'bg-sky-600 text-white font-semibold shadow-md shadow-sky-600/30' : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/70' ?>">
                    <i class="fa-solid <?= $item['icon'] ?> w-5 text-center text-base <?= $isActive ? 'text-white' : 'text-slate-400 group-hover:text-white' ?>"></i>
                    <span><?= e($item['label']) ?></span>
                </a>
            <?php endif; ?>
        <?php endforeach; ?>
    </nav>

    <!-- Sidebar Footer / Logout -->
    <div class="p-3 border-t border-slate-800 bg-slate-950/20">
        <a href="../logout.php" onclick="return confirm('Apakah Anda yakin ingin keluar?');" class="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-rose-400 hover:bg-rose-500/10 hover:text-rose-300 transition-colors">
            <i class="fa-solid fa-right-from-bracket w-5 text-center text-base"></i>
            <span>Logout</span>
        </a>
    </div>
</aside>
