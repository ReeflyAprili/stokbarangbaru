<?php
// pages/barang_masuk.php
$pageTitle = 'Barang Masuk';
require_once __DIR__ . '/../includes/header.php';
$pdo = getDBConnection();

// Auto generate transaction number (BM-YYYYMMDD-001)
$todayStr = date('Ymd');
$countToday = $pdo->query("SELECT COUNT(*) FROM stock_in WHERE DATE(created_at) = CURDATE()")->fetchColumn() ?: 0;
$autoNoTx = 'BM-' . $todayStr . '-' . str_pad($countToday + 1, 3, '0', STR_PAD_LEFT);

// Fetch all products for dropdown
$products = $pdo->query("SELECT id, kode_barang, nama_barang, satuan, harga_beli, stok FROM products ORDER BY nama_barang ASC")->fetchAll();

// Fetch history
$history = $pdo->query("
    SELECT si.*, p.kode_barang, p.nama_barang, p.satuan, u.nama as nama_user
    FROM stock_in si
    JOIN products p ON si.product_id = p.id
    LEFT JOIN users u ON si.created_by = u.id
    ORDER BY si.created_at DESC, si.id DESC
")->fetchAll();
?>

<!-- Grid Form & Info Card -->
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
    
    <!-- Form Card (2 cols on large) -->
    <div class="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-subtle">
        <div class="flex items-center justify-between pb-4 mb-4 border-b border-slate-100">
            <div>
                <h3 class="text-base font-bold text-slate-800">Form Transaksi Barang Masuk</h3>
                <p class="text-xs text-slate-500">Penerimaan pasokan barang baru ke dalam gudang</p>
            </div>
            <span class="p-2 bg-emerald-50 text-emerald-700 rounded-xl text-xs font-bold flex items-center gap-1.5 border border-emerald-200">
                <i class="fa-solid fa-arrow-down"></i> Stok +
            </span>
        </div>

        <form action="../actions/barang_masuk_action.php" method="POST" class="space-y-4">
            <?= csrfField() ?>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Nomor Transaksi</label>
                    <input type="text" name="nomor_transaksi" value="<?= e($autoNoTx) ?>" required readonly class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-slate-100 font-mono font-bold text-slate-700 text-sm">
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Tanggal Masuk</label>
                    <input type="date" name="tanggal" value="<?= date('Y-m-d') ?>" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 text-sm">
                </div>

                <div class="sm:col-span-2">
                    <label class="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Pilih Barang</label>
                    <select id="select_product" name="product_id" required onchange="onSelectProduct(this)" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 text-sm font-medium">
                        <option value="">-- Pilih Barang --</option>
                        <?php foreach ($products as $p): ?>
                            <option value="<?= $p['id'] ?>" data-satuan="<?= e($p['satuan']) ?>" data-harga="<?= $p['harga_beli'] ?>" data-stok="<?= $p['stok'] ?>">
                                [<?= e($p['kode_barang']) ?>] <?= e($p['nama_barang']) ?> (Stok: <?= number_format($p['stok']) ?> <?= e($p['satuan']) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Jumlah Masuk</label>
                    <div class="relative">
                        <input type="number" name="jumlah" min="1" required placeholder="0" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 font-mono text-sm font-bold">
                        <span id="label_satuan" class="absolute inset-y-0 right-0 flex items-center pr-3.5 text-xs text-slate-400 font-semibold">Unit</span>
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Harga Beli Satuan (Rp)</label>
                    <input type="number" step="0.01" id="input_harga" name="harga_beli" value="0" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 font-mono text-sm">
                </div>

                <div class="sm:col-span-2">
                    <label class="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Keterangan / Catatan Vendor</label>
                    <textarea name="keterangan" rows="2" placeholder="Contoh: Pembelian dari Supplier PT Maju Jaya..." class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 text-sm"></textarea>
                </div>
            </div>

            <div class="pt-3 border-t border-slate-100 flex justify-end">
                <button type="submit" class="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm px-6 py-2.5 rounded-xl shadow-md shadow-emerald-600/20 transition-all">
                    <i class="fa-solid fa-floppy-disk"></i>
                    <span>Simpan Barang Masuk</span>
                </button>
            </div>
        </form>
    </div>

    <!-- Instruction Card -->
    <div class="bg-gradient-to-br from-slate-900 to-sky-900 text-white p-6 rounded-2xl shadow-xl flex flex-col justify-between">
        <div>
            <div class="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center text-sky-400 text-2xl mb-4 backdrop-blur-sm">
                <i class="fa-solid fa-calculator"></i>
            </div>
            <h4 class="text-lg font-bold mb-2">Rumus Otomatisasi Stok</h4>
            <p class="text-xs text-slate-300 leading-relaxed mb-4">
                Setiap kali data barang masuk disimpan ke sistem, stok fisik di database akan bertambah secara otomatis sesuai dengan rumus:
            </p>
            <div class="bg-white/10 backdrop-blur-md p-3.5 rounded-xl font-mono text-xs text-sky-300 font-bold border border-white/10">
                Stok Baru = Stok Lama + Jumlah Masuk
            </div>
        </div>

        <div class="pt-6 border-t border-white/10 text-[11px] text-slate-400 flex items-center gap-2">
            <i class="fa-solid fa-shield-halved text-sky-400"></i>
            <span>Transaksi dicatat dengan PDO Transaction safety.</span>
        </div>
    </div>

</div>

<!-- Table History -->
<div class="bg-white rounded-2xl border border-slate-200/80 shadow-subtle overflow-hidden">
    <div class="p-5 border-b border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
            <h3 class="text-base font-bold text-slate-800">Riwayat Barang Masuk</h3>
            <p class="text-xs text-slate-500">Daftar transaksi penerimaan stok barang</p>
        </div>
        
        <div class="relative w-full sm:w-72">
            <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                <i class="fa-solid fa-magnifying-glass"></i>
            </span>
            <input type="text" id="searchMasuk" onkeyup="filterTable('searchMasuk', 'tableMasuk')" placeholder="Cari no tx, nama barang, user..." class="w-full pl-10 pr-4 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500">
        </div>
    </div>

    <div class="overflow-x-auto">
        <table id="tableMasuk" class="w-full text-left text-sm text-slate-600">
            <thead class="bg-slate-50 text-xs uppercase tracking-wider text-slate-500 font-semibold border-b border-slate-200/80">
                <tr>
                    <th class="px-5 py-3.5">No. Transaksi</th>
                    <th class="px-5 py-3.5">Tanggal</th>
                    <th class="px-5 py-3.5">Kode</th>
                    <th class="px-5 py-3.5">Nama Barang</th>
                    <th class="px-5 py-3.5 text-right">Jumlah Masuk</th>
                    <th class="px-5 py-3.5">User</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
                <?php if (empty($history)): ?>
                    <tr>
                        <td colspan="6" class="px-5 py-8 text-center text-slate-400">
                            Belum ada riwayat transaksi barang masuk.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($history as $h): ?>
                        <tr class="hover:bg-slate-50/80 transition-colors">
                            <td class="px-5 py-3.5 font-mono text-xs font-bold text-sky-700">
                                <?= e($h['nomor_transaksi']) ?>
                            </td>
                            <td class="px-5 py-3.5 text-xs text-slate-600">
                                <?= date('d/m/Y', strtotime($h['tanggal'])) ?>
                            </td>
                            <td class="px-5 py-3.5 font-mono text-xs text-slate-500">
                                <?= e($h['kode_barang']) ?>
                            </td>
                            <td class="px-5 py-3.5 font-semibold text-slate-800">
                                <?= e($h['nama_barang']) ?>
                                <?php if (!empty($h['keterangan'])): ?>
                                    <div class="text-[11px] font-normal text-slate-400 italic"><?= e($h['keterangan']) ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="px-5 py-3.5 text-right font-mono font-bold text-emerald-600">
                                +<?= number_format($h['jumlah']) ?> <?= e($h['satuan']) ?>
                            </td>
                            <td class="px-5 py-3.5 text-xs text-slate-500">
                                <i class="fa-regular fa-user mr-1 text-slate-400"></i><?= e($h['nama_user'] ?? 'System') ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function onSelectProduct(select) {
    const selectedOption = select.options[select.selectedIndex];
    const satuan = selectedOption.getAttribute('data-satuan') || 'Unit';
    const harga = selectedOption.getAttribute('data-harga') || '0';
    
    document.getElementById('label_satuan').innerText = satuan;
    document.getElementById('input_harga').value = harga;
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
