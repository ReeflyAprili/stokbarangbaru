<?php
// actions/barang_keluar_action.php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../pages/barang_keluar.php");
    exit();
}

$csrf_token = $_POST['csrf_token'] ?? '';
if (!verifyCSRFToken($csrf_token)) {
    setFlash('danger', 'Sesi invalid (CSRF Token error).');
    header("Location: ../pages/barang_keluar.php");
    exit();
}

$nomor_transaksi = trim($_POST['nomor_transaksi'] ?? '');
$tanggal = trim($_POST['tanggal'] ?? date('Y-m-d'));
$product_id = (int)($_POST['product_id'] ?? 0);
$jumlah = (int)($_POST['jumlah'] ?? 0);
$tujuan = trim($_POST['tujuan'] ?? '');
$keterangan = trim($_POST['keterangan'] ?? '');
$user_id = $_SESSION['user_id'] ?? null;

if ($product_id <= 0 || $jumlah <= 0) {
    setFlash('danger', 'Pilih barang dan jumlah keluar wajib lebih dari 0.');
    header("Location: ../pages/barang_keluar.php");
    exit();
}

$pdo = getDBConnection();

try {
    // Check current stock availability
    $stmtProd = $pdo->prepare("SELECT nama_barang, stok, satuan FROM products WHERE id = :pid LIMIT 1");
    $stmtProd->execute([':pid' => $product_id]);
    $prod = $stmtProd->fetch();

    if (!$prod) {
        setFlash('danger', 'Barang tidak ditemukan.');
        header("Location: ../pages/barang_keluar.php");
        exit();
    }

    // MANDATORY REQUIREMENT VALIDATION:
    if ($prod['stok'] < $jumlah) {
        setFlash('danger', 'Stok barang tidak mencukupi.');
        header("Location: ../pages/barang_keluar.php");
        exit();
    }

    $pdo->beginTransaction();

    // 1. Insert transaction into stock_out
    $stmtOut = $pdo->prepare("
        INSERT INTO stock_out (nomor_transaksi, tanggal, product_id, jumlah, tujuan, keterangan, created_by)
        VALUES (:no_tx, :tgl, :pid, :jml, :tujuan, :ket, :uid)
    ");
    $stmtOut->execute([
        ':no_tx' => $nomor_transaksi,
        ':tgl' => $tanggal,
        ':pid' => $product_id,
        ':jml' => $jumlah,
        ':tujuan' => $tujuan,
        ':ket' => $keterangan,
        ':uid' => $user_id
    ]);

    // 2. Update product stock: Stok Baru = Stok Lama - Jumlah Keluar
    $stmtUp = $pdo->prepare("
        UPDATE products 
        SET stok = stok - :jml 
        WHERE id = :pid
    ");
    $stmtUp->execute([
        ':jml' => $jumlah,
        ':pid' => $product_id
    ]);

    $pdo->commit();
    setFlash('success', "Transaksi Barang Keluar [$nomor_transaksi] berhasil disimpan dan stok telah berkurang $jumlah unit.");
} catch (PDOException $e) {
    $pdo->rollBack();
    if ($e->getCode() == 23000) {
        setFlash('danger', "Nomor transaksi '$nomor_transaksi' sudah digunakan.");
    } else {
        setFlash('danger', 'Gagal memproses barang keluar: ' . $e->getMessage());
    }
}

header("Location: ../pages/barang_keluar.php");
exit();
