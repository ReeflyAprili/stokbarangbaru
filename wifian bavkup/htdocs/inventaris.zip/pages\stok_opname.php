<?php
// pages/stok_opname.php
$pageTitle = 'Stok Opname';
require_once __DIR__ . '/../includes/header.php';
$pdo = getDBConnection();

// Fetch products for dropdown
$products = $pdo->query("SELECT id, kode_barang, nama_barang, satuan, stok FROM products ORDER BY nama_barang ASC")->fetchAll();

// Fetch opname history
$history = $pdo->query("
    SELECT so.*, p.kode_barang, p.nama_barang, p.satuan, u.nama as nama_user
    FROM stock_opname so
    JOIN products p ON so.product_id = p.id
    LEFT JOIN users u ON so.created_by = u.id
    ORDER BY so.created_at DESC, so.id DESC
")->fetchAll();
?>

<!-- Grid Form & Info Card -->
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
    
    <!-- Form Card -->
    <div class="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-subtle">
        <div class="flex items-center justify-between pb-4 mb-4 border-b border-slate-100">
            <div>
                <h3 class="text-base font-bold text-slate-800">Form Audit Stok Opname</h3>
                <p class="text-xs text-slate-500">Pencocokan stok fisik di gudang dengan catatan sistem</p>
            </div>
            <span class="p-2 bg-purple-50 text-purple-700 rounded-xl text-xs font-bold border border-purple-200 flex items-center gap-1.5">
                <i class="fa-solid fa-clipboard-check"></i> Audit Stock
            </span>
        </div>

        <form action="../actions/opname_action.php" method="POST" class="space-y-4">
            <?= csrfField() ?>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Tanggal Opname</label>
                    <input type="date" name="tanggal" value="<?= date('Y-m-d') ?>" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 text-sm">
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Pilih Barang</label>
                    <select id="select_product" name="product_id" required onchange="onSelectProductOpname(this)" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 text-sm font-medium">
                        <option value="">-- Pilih Barang --</option>
                        <?php foreach ($products as $p): ?>
                            <option value="<?= $p['id'] ?>" data-stok="<?= $p['stok'] ?>" data-satuan="<?= e($p['satuan']) ?>">
                                [<?= e($p['kode_barang']) ?>] <?= e($p['nama_barang']) ?> (Stok Sistem: <?= number_format($p['stok']) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Stok Sistem</label>
                    <input type="number" id="stok_sistem" name="stok_sistem" value="0" readonly class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-slate-100 font-mono text-sm font-bold text-slate-600">
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Stok Fisik Gudang</label>
                    <input type="number" id="stok_fisik" name="stok_fisik" value="0" min="0" required onkeyup="calcSelisih()" onchange="calcSelisih()" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 font-mono text-sm font-bold">
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Selisih (Fisik - Sistem)</label>
                    <input type="number" id="selisih" name="selisih" value="0" readonly class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-slate-100 font-mono text-sm font-extrabold text-slate-800">
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Status Penyesuaian</label>
                    <div id="status_box" class="px-3.5 py-2 rounded-xl text-xs font-bold text-slate-500 bg-slate-100 border border-slate-200 flex items-center h-[42px]">
                        -
                    </div>
                </div>

                <div class="sm:col-span-2">
                    <label class="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Keterangan / Alasan Selisih</label>
                    <textarea name="keterangan" rows="2" placeholder="Alasan jika ada selisih barang misal: rusak, hilang, atau salah hitung..." class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 text-sm"></textarea>
                </div>
            </div>

            <div class="pt-3 border-t border-slate-100 flex justify-end">
                <button type="submit" class="inline-flex items-center gap-2 bg-purple-600 hover:bg-purple-700 text-white font-semibold text-sm px-6 py-2.5 rounded-xl shadow-md shadow-purple-600/20 transition-all">
                    <i class="fa-solid fa-square-check"></i>
                    <span>Simpan & Adjust Stok</span>
                </button>
            </div>
        </form>
    </div>

    <!-- Guideline Card -->
    <div class="bg-gradient-to-br from-slate-900 to-purple-950 text-white p-6 rounded-2xl shadow-xl flex flex-col justify-between">
        <div>
            <div class="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center text-purple-400 text-2xl mb-4 backdrop-blur-sm">
                <i class="fa-solid fa-list-check"></i>
            </div>
            <h4 class="text-lg font-bold mb-2">Penyesuaian Stok Opname</h4>
            <p class="text-xs text-slate-300 leading-relaxed mb-3">
                Rumus Perhitungan Selisih:
            </p>
            <div class="bg-white/10 backdrop-blur-md p-3 rounded-xl font-mono text-xs text-purple-300 font-bold border border-white/10 mb-4">
                Selisih = Stok Fisik - Stok Sistem
            </div>
            <ul class="text-xs space-y-2 text-slate-300">
                <li class="flex items-center gap-2">
                    <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
                    <span><strong>Selisih 0:</strong> Status <em>Sesuai</em></span>
                </li>
                <li class="flex items-center gap-2">
                    <span class="w-2 h-2 rounded-full bg-blue-400"></span>
                    <span><strong>Selisih &gt; 0:</strong> Status <em>Lebih</em></span>
                </li>
                <li class="flex items-center gap-2">
                    <span class="w-2 h-2 rounded-full bg-rose-400"></span>
                    <span><strong>Selisih &lt; 0:</strong> Status <em>Kurang</em></span>
                </li>
            </ul>
        </div>

        <div class="pt-6 border-t border-white/10 text-[11px] text-slate-400 flex items-center gap-2">
            <i class="fa-solid fa-sync text-purple-400"></i>
            <span>Stok sistem akan otomatis diubah sesuai Stok Fisik.</span>
        </div>
    </div>

</div>

<!-- Table History Opname -->
<div class="bg-white rounded-2xl border border-slate-200/80 shadow-subtle overflow-hidden">
    <div class="p-5 border-b border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
            <h3 class="text-base font-bold text-slate-800">Riwayat Stok Opname</h3>
            <p class="text-xs text-slate-500">Daftar pemeriksaan audit fisik inventaris</p>
        </div>
        
        <div class="relative w-full sm:w-72">
            <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                <i class="fa-solid fa-magnifying-glass"></i>
            </span>
            <input type="text" id="searchOpname" onkeyup="filterTable('searchOpname', 'tableOpname')" placeholder="Cari barang, user, keterangan..." class="w-full pl-10 pr-4 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500">
        </div>
    </div>

    <div class="overflow-x-auto">
        <table id="tableOpname" class="w-full text-left text-sm text-slate-600">
            <thead class="bg-slate-50 text-xs uppercase tracking-wider text-slate-500 font-semibold border-b border-slate-200/80">
                <tr>
                    <th class="px-5 py-3.5">Tanggal</th>
                    <th class="px-5 py-3.5">Kode</th>
                    <th class="px-5 py-3.5">Nama Barang</th>
                    <th class="px-5 py-3.5 text-center">Stok Sistem</th>
                    <th class="px-5 py-3.5 text-center">Stok Fisik</th>
                    <th class="px-5 py-3.5 text-center">Selisih</th>
                    <th class="px-5 py-3.5">Status</th>
                    <th class="px-5 py-3.5">User</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
                <?php if (empty($history)): ?>
                    <tr>
                        <td colspan="8" class="px-5 py-8 text-center text-slate-400">
                            Belum ada riwayat stok opname.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($history as $h): ?>
                        <?php
                            $sel = (int)$h['selisih'];
                            if ($sel === 0) {
                                $statusLbl = '<span class="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300"><i class="fa-solid fa-check text-[10px]"></i> Sesuai</span>';
                            } elseif ($sel > 0) {
                                $statusLbl = '<span class="px-2.5 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-800 border border-blue-300"><i class="fa-solid fa-plus text-[10px]"></i> Lebih</span>';
                            } else {
                                $statusLbl = '<span class="px-2.5 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 border border-rose-300"><i class="fa-solid fa-minus text-[10px]"></i> Kurang</span>';
                            }
                        ?>
                        <tr class="hover:bg-slate-50/80 transition-colors">
                            <td class="px-5 py-3.5 text-xs text-slate-600 font-medium">
                                <?= date('d/m/Y', strtotime($h['tanggal'])) ?>
                            </td>
                            <td class="px-5 py-3.5 font-mono text-xs text-slate-500">
                                <?= e($h['kode_barang']) ?>
                            </td>
                            <td class="px-5 py-3.5 font-semibold text-slate-800">
                                <?= e($h['nama_barang']) ?>
                                <?php if (!empty($h['keterangan'])): ?>
                                    <div class="text-[11px] font-normal text-slate-400 italic"><?= e($h['keterangan']) ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="px-5 py-3.5 text-center font-mono text-slate-600">
                                <?= number_format($h['stok_sistem']) ?>
                            </td>
                            <td class="px-5 py-3.5 text-center font-mono font-bold text-slate-800">
                                <?= number_format($h['stok_fisik']) ?>
                            </td>
                            <td class="px-5 py-3.5 text-center font-mono font-bold <?= $sel === 0 ? 'text-emerald-600' : ($sel > 0 ? 'text-blue-600' : 'text-rose-600') ?>">
                                <?= ($sel > 0 ? '+' : '') . number_format($sel) ?>
                            </td>
                            <td class="px-5 py-3.5">
                                <?= $statusLbl ?>
                            </td>
                            <td class="px-5 py-3.5 text-xs text-slate-500">
                                <i class="fa-regular fa-user mr-1 text-slate-400"></i><?= e($h['nama_user'] ?? 'System') ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function onSelectProductOpname(select) {
    const selectedOption = select.options[select.selectedIndex];
    const stokSys = parseInt(selectedOption.getAttribute('data-stok') || '0');
    
    document.getElementById('stok_sistem').value = stokSys;
    document.getElementById('stok_fisik').value = stokSys;
    calcSelisih();
}

function calcSelisih() {
    const sys = parseInt(document.getElementById('stok_sistem').value || '0');
    const fis = parseInt(document.getElementById('stok_fisik').value || '0');
    const sel = fis - sys;
    
    const selInput = document.getElementById('selisih');
    selInput.value = sel;

    const statusBox = document.getElementById('status_box');
    if (sel === 0) {
        statusBox.className = "px-3.5 py-2 rounded-xl text-xs font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 flex items-center h-[42px]";
        statusBox.innerHTML = '<i class="fa-solid fa-circle-check text-emerald-600 mr-1.5"></i> Sesuai (0)';
    } else if (sel > 0) {
        statusBox.className = "px-3.5 py-2 rounded-xl text-xs font-bold text-blue-800 bg-blue-50 border border-blue-200 flex items-center h-[42px]";
        statusBox.innerHTML = '<i class="fa-solid fa-circle-plus text-blue-600 mr-1.5"></i> Lebih (+' + sel + ')';
    } else {
        statusBox.className = "px-3.5 py-2 rounded-xl text-xs font-bold text-rose-800 bg-rose-50 border border-rose-200 flex items-center h-[42px]";
        statusBox.innerHTML = '<i class="fa-solid fa-circle-minus text-rose-600 mr-1.5"></i> Kurang (' + sel + ')';
    }
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
