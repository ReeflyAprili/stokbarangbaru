<?php
// config/database.php
// Connection configuration for PT Wifian Solution Inventory System

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'database_inventory');
define('DB_PORT', '3306');

function getDBConnection() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Attempt to connect without dbname to auto-create or show helpful guide
            try {
                $dsnNoDb = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";charset=utf8mb4";
                $tmpPdo = new PDO($dsnNoDb, DB_USER, DB_PASS);
                $tmpPdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                
                // Reconnect to newly created DB
                $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]);

                // Check if users table exists, if not auto seed database_inventory.sql
                $tableCheck = $pdo->query("SHOW TABLES LIKE 'users'")->rowCount();
                if ($tableCheck === 0) {
                    $sqlFile = __DIR__ . '/../database/database_inventory.sql';
                    if (file_exists($sqlFile)) {
                        $sqlContent = file_get_contents($sqlFile);
                        $pdo->exec($sqlContent);
                    }
                }
            } catch (PDOException $ex) {
                die("<div style='font-family: sans-serif; padding: 2rem; background: #fef2f2; border: 1px solid #fca5a5; color: #991b1b; border-radius: 8px; margin: 2rem;'>
                    <h2 style='margin-top:0;'>Koneksi Database Gagal</h2>
                    <p>Gagal terhubung ke MySQL Database server. Pastikan XAMPP/Laragon MySQL service sudah aktif dan konfigurasi di <code>config/database.php</code> sudah sesuai.</p>
                    <p><strong>Pesan Error:</strong> " . htmlspecialchars($ex->getMessage()) . "</p>
                </div>");
            }
        }
    }
    return $pdo;
}
