<?php
// login.php
session_start();
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';

if (isLoggedIn()) {
    header("Location: pages/dashboard.php");
    exit();
}

$settings = getStoreSettings();
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?= e($settings['nama_toko']) ?></title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: {
                            50: '#f0f9ff',
                            500: '#0284c7',
                            600: '#0284c7',
                            700: '#0369a1',
                        }
                    }
                }
            }
        }
    </script>
    <!-- FontAwesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="assets/css/custom.css">
</head>
<body class="bg-gradient-to-br from-slate-900 via-slate-800 to-sky-950 min-h-screen flex items-center justify-center p-4">

    <div class="w-full max-w-md bg-white/95 backdrop-blur-xl rounded-2xl shadow-2xl overflow-hidden border border-white/20">
        
        <!-- Header Section -->
        <div class="bg-slate-950 p-8 text-center text-white relative">
            <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-tr from-sky-500 to-indigo-600 mb-4 shadow-lg shadow-sky-500/30">
                <i class="fa-solid fa-boxes-stacked text-3xl"></i>
            </div>
            <h2 class="text-2xl font-bold tracking-tight text-white mb-1">INVENTORY SYSTEM</h2>
            <p class="text-sky-400 font-medium text-sm"><?= e($settings['nama_toko']) ?></p>
            <p class="text-slate-400 text-xs mt-1">Sistem Pengelolaan Stok Toko Bangunan & ISP</p>
        </div>

        <!-- Form Body -->
        <div class="p-8">
            
            <?php if ($flash): ?>
                <div class="mb-6 p-4 rounded-xl text-sm flex items-center gap-3 <?= $flash['type'] === 'success' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-rose-50 text-rose-800 border border-rose-200' ?>">
                    <i class="fa-solid <?= $flash['type'] === 'success' ? 'fa-circle-check text-emerald-600' : 'fa-circle-exclamation text-rose-600' ?> text-lg"></i>
                    <span><?= e($flash['message']) ?></span>
                </div>
            <?php endif; ?>

            <form action="actions/login_action.php" method="POST" class="space-y-5">
                <?= csrfField() ?>
                
                <div>
                    <label for="username" class="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">Username</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                            <i class="fa-solid fa-user"></i>
                        </span>
                        <input type="text" id="username" name="username" required autofocus placeholder="Masukkan username" class="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent text-sm transition-all">
                    </div>
                </div>

                <div>
                    <label for="password" class="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">Password</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                            <i class="fa-solid fa-lock"></i>
                        </span>
                        <input type="password" id="password" name="password" required placeholder="Masukkan password" class="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent text-sm transition-all">
                    </div>
                </div>

                <button type="submit" class="w-full bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-700 hover:to-indigo-700 text-white font-bold py-3.5 px-4 rounded-xl shadow-lg shadow-sky-600/30 transition-all duration-200 flex items-center justify-center gap-2">
                    <span>LOGIN KE SISTEM</span>
                    <i class="fa-solid fa-arrow-right"></i>
                </button>
            </form>

            <!-- Default Credentials Tip Card -->
            <div class="mt-6 p-4 rounded-xl bg-slate-50 border border-slate-200/80 text-xs text-slate-600 space-y-1">
                <div class="font-bold text-slate-700 flex items-center gap-1.5 mb-1">
                    <i class="fa-solid fa-key text-amber-500"></i> Akun Demo Default:
                </div>
                <div class="flex justify-between">
                    <span>Admin: <code class="bg-white px-1.5 py-0.5 rounded border text-slate-800 font-mono">admin</code></span>
                    <span>Pass: <code class="bg-white px-1.5 py-0.5 rounded border text-slate-800 font-mono">admin123</code></span>
                </div>
                <div class="flex justify-between pt-1 border-t border-slate-200/60">
                    <span>Staff: <code class="bg-white px-1.5 py-0.5 rounded border text-slate-800 font-mono">staff</code></span>
                    <span>Pass: <code class="bg-white px-1.5 py-0.5 rounded border text-slate-800 font-mono">admin123</code></span>
                </div>
            </div>
        </div>

        <div class="bg-slate-50 py-3 text-center text-xs text-slate-400 border-t border-slate-100">
            &copy; <?= date('Y') ?> <?= e($settings['nama_toko']) ?>
        </div>
    </div>

</body>
</html>
